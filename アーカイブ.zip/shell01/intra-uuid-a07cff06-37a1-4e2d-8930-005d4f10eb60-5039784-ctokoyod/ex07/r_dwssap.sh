cat /etc/passwd | \
sed '/^#/d' | \
cut -d ':' -f 1 | \
sort -r | \
awk 'NR >= ENVIRON["FT_LINE1"] && NR <= ENVIRON["FT_LINE2"] && NR % 2 == 0 { print }' | \
rev | \
sed 's/¥n/, /g' | \
sed 's/, $/./'