/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By:  ctokoyod < ctokoyod@student.42tokyo.jp    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/16 23:12:17 by  ctokoyod         #+#    #+#             */
/*   Updated: 2023/08/17 15:55:53 by  ctokoyod        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strstr(char *str, char *to_find)
{
	char	*p_str;
	char	*p_tofind;

	p_str = str;
	p_tofind = to_find;
	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{
		while (*p_str != '\0' && *p_tofind != '\0')
		{
			p_str++;
			p_tofind++;
		}
		if (p_tofind == '\0')
		{
			return (str);
		}
		str++;
	}
	return (0);
}

// #include <stdio.h>
// #include <string.h>

// /*
// string search
// */
// int	main(void)
// {
// 	char str[20] = "Hello, ";
// 	char to_find[20] = "12345";
// 	char str_t[20] = "Hello, "; // 探す対象
// 	char to_find_t[20] = "12345"; // 探すパターン

// 	char *sp;
// 	char *sp_t;

// 	sp = ft_strstr(str, to_find);
// 	sp_t = strstr(str_t, to_find_t);

// 	printf("ft_strstr: %s\n", sp);
// 	printf("strstr: %s\n", sp_t);
// }