git log -n 5 --pretty=tformat:"%H"
