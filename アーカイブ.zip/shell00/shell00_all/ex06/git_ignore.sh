git ls-files --others --ignored --exclude-standard /Users/ctokoyod/github/intra-uuid-7a19ef49-a772-4030-b6eb-237cdef949ef-5032394-ctokoyod
