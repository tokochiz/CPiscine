/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By:  ctokoyod < ctokoyod@student.42tokyo.jp    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 10:17:39 by  ctokoyod         #+#    #+#             */
/*   Updated: 2023/08/20 11:57:14 by  ctokoyod        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

// unsigned namespace std;

// #define N 10
// #define FREE -1
// #define NOT_FREE 1

// int

// int ft_ten_queens_puzzle(void);

// int main(int argc, char **argv[])
// {

// }